# HoloLink v0.2 Architecture

HoloLink is an AI Vehicle Intelligence & ANPR Orchestration Platform.

## Target flow

Camera / ANPR source
→ Adapter
→ Normalized ANPR Event
→ Event Processor
→ PostgreSQL
→ Vehicle Intelligence / Parking / Alerts
→ MCP Tools
→ AI Agent / Voice
→ Dashboard / API

## v0.2 objectives

- Vendor-neutral ANPR event schema
- Multi-site and multi-camera model
- PostgreSQL-ready data layer
- Vehicle history and last-seen intelligence
- Parking session lifecycle
- Alert/rules foundation
- MCP tool contracts
- Health monitoring
- Docker and CI/CD foundations

This release intentionally keeps the existing v0.1 implementation intact and adds a modular v0.2 foundation around it.
