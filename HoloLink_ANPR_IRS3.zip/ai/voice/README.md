# Voice Layer

Planned pipeline:

Speech-to-Text → AI Agent → MCP/Domain Tools → Response → Text-to-Speech.

Voice is intentionally separated from ANPR and database logic.
