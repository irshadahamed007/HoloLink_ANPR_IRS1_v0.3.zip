# AI Agent

The AI layer should translate natural-language vehicle questions into safe,
structured operations.

Examples:

- "Where was A12345 last seen?"
- "How many times did A12345 visit this month?"
- "Show white Toyota SUVs entering Site-001 today."

The agent should call domain/MCP tools rather than directly accessing the database.
