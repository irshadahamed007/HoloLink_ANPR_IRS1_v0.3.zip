# HoloLink v0.2

**AI Vehicle Intelligence & ANPR Orchestration Platform**

This release adds a modular foundation around the original HoloLink v0.1 POC.

## Core architecture

Camera/ANPR → Adapter → Normalized Event → Intelligence → PostgreSQL → MCP → AI/Voice

## What's new

- Vendor-neutral ANPR event contract
- Multi-site and multi-camera foundation
- Vehicle intelligence service
- Alert rule definitions
- MCP tool contracts
- PostgreSQL starter schema
- Redis event-bus foundation
- Health monitoring foundation
- Security baseline
- Synthetic test data
- CI workflow
- Deployment documentation

## Important

The original v0.1 files are preserved. Review and migrate existing database/API
logic into the new modules incrementally rather than performing a risky rewrite.

## Next implementation order

1. Connect existing FastAPI endpoints to the canonical ANPR event schema.
2. Add SQLAlchemy models and Alembic migrations.
3. Connect PostgreSQL repository/service layer.
4. Add real ANPR webhook/camera adapters.
5. Add MCP SDK implementation.
6. Add AI agent orchestration.
7. Add dashboard/WebSocket live events.
8. Add production authentication, RBAC and audit logging.
