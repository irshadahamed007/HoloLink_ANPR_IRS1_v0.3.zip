# HoloLink Simple Upload

Install:
`pip install -r requirements-simple.txt`

Start API:
`uvicorn backend.main:app --reload`

Open:
`http://127.0.0.1:8000/docs`

Run simulator in another terminal:
`python simulator/simulator.py`

Main files:
- `backend/main.py`
- `backend/models.py`
- `simulator/simulator.py`
- `requirements-simple.txt`

Only synthetic ANPR data is included.
