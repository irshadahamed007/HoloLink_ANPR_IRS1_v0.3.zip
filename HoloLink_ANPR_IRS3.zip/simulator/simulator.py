import json,time,urllib.request

API_URL="http://127.0.0.1:8000/api/anpr/event"
EVENTS=[
{"plate_number":"A12345","site_id":"SITE-001","camera_id":"CAM-001","direction":"ENTRY","country":"UAE","state":"Dubai","vehicle_type":"SUV","vehicle_make":"Toyota","vehicle_model":"Land Cruiser","vehicle_color":"White","confidence":0.96},
{"plate_number":"B55672","site_id":"SITE-001","camera_id":"CAM-002","direction":"EXIT","country":"UAE","state":"Abu Dhabi","vehicle_type":"Sedan","vehicle_make":"Nissan","vehicle_model":"Altima","vehicle_color":"Black","confidence":0.94}
]

def send(event):
    data=json.dumps(event).encode()
    req=urllib.request.Request(API_URL,data=data,headers={"Content-Type":"application/json"},method="POST")
    with urllib.request.urlopen(req,timeout=5) as r: print(r.read().decode())

if __name__=="__main__":
    print("HoloLink simulator started. Ctrl+C to stop.")
    i=0
    while True:
        send(EVENTS[i%len(EVENTS)]); i+=1; time.sleep(3)
