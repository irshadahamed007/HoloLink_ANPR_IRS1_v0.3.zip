import argparse
import random
import time

import requests

API_URL = "http://127.0.0.1:8000/api/v1/anpr/events"

PLATES = ["A12345", "B55421", "C99821", "D45221", "E77881"]
VEHICLES = [
    ("Toyota", "Land Cruiser", "White", "SUV"),
    ("Nissan", "Patrol", "Black", "SUV"),
    ("BMW", "X5", "Blue", "SUV"),
    ("Toyota", "Camry", "Silver", "Sedan"),
]
CAMERAS = ["CAM-001", "CAM-002", "CAM-003", "CAM-004"]


def create_event():
    make, model, color, vehicle_type = random.choice(VEHICLES)
    return {
        "plate": random.choice(PLATES),
        "country": "UAE",
        "category": "Private",
        "vehicle_type": vehicle_type,
        "make": make,
        "model": model,
        "color": color,
        "camera_id": random.choice(CAMERAS),
        "site_id": "SITE-001",
        "direction": random.choice(["ENTRY", "EXIT"]),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--count", type=int, default=10)
    parser.add_argument("--delay", type=float, default=0.5)
    args = parser.parse_args()

    for _ in range(args.count):
        event = create_event()
        response = requests.post(API_URL, json=event, timeout=5)
        response.raise_for_status()
        print(response.json())
        time.sleep(args.delay)


if __name__ == "__main__":
    main()
