"""Vehicle intelligence service contracts."""
from collections import defaultdict

class VehicleIntelligence:
    def __init__(self):
        self._events = defaultdict(list)

    def record(self, event):
        self._events[event.plate_number].append(event)

    def history(self, plate_number):
        return list(self._events.get(plate_number, []))

    def last_seen(self, plate_number):
        events = self._events.get(plate_number, [])
        return max(events, key=lambda e: e.timestamp) if events else None

    def visit_count(self, plate_number):
        return len(self._events.get(plate_number, []))
