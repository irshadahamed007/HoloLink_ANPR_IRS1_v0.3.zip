"""Initial alert rule definitions."""
from dataclasses import dataclass

@dataclass(frozen=True)
class AlertRule:
    name: str
    description: str
    severity: str

DEFAULT_RULES = [
    AlertRule("BLACKLISTED_VEHICLE", "Vehicle matches a configured blacklist.", "critical"),
    AlertRule("LOW_CONFIDENCE", "ANPR confidence is below the configured threshold.", "warning"),
    AlertRule("CAMERA_OFFLINE", "Camera heartbeat has expired.", "critical"),
    AlertRule("SITE_OFFLINE", "Site is not reachable.", "critical"),
    AlertRule("LONG_PARKING", "Parking duration exceeds the configured limit.", "warning"),
]
