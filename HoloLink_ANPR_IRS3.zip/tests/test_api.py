from fastapi.testclient import TestClient
from backend.main import app

client = TestClient(app)


def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "healthy"


def test_create_and_search_vehicle():
    payload = {
        "plate": "TEST123",
        "country": "UAE",
        "category": "Private",
        "vehicle_type": "SUV",
        "make": "Toyota",
        "model": "Land Cruiser",
        "color": "White",
        "camera_id": "CAM-TEST",
        "site_id": "SITE-TEST",
        "direction": "ENTRY",
    }

    created = client.post("/api/v1/anpr/events", json=payload)
    assert created.status_code == 201

    found = client.get("/api/v1/vehicles/TEST123")
    assert found.status_code == 200
    assert found.json()["plate"] == "TEST123"
