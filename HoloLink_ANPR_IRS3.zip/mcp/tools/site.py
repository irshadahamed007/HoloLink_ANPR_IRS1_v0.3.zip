"""MCP-facing site and camera tool contracts."""
def get_site_status(site_id: str):
    return {"tool": "get_site_status", "site_id": site_id}

def get_camera_status(camera_id: str):
    return {"tool": "get_camera_status", "camera_id": camera_id}
