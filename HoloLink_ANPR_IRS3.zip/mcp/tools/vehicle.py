"""MCP-facing vehicle tool contracts.

These functions are intentionally framework-neutral so an MCP SDK can be
introduced without coupling the core domain to a specific SDK version.
"""
def search_vehicle(plate_number: str):
    return {"tool": "search_vehicle", "plate_number": plate_number}

def get_vehicle_history(plate_number: str):
    return {"tool": "get_vehicle_history", "plate_number": plate_number}

def get_vehicle_last_seen(plate_number: str):
    return {"tool": "get_vehicle_last_seen", "plate_number": plate_number}
