# Dashboard

Planned v0.7 module for live ANPR events, vehicle search, parking status, and analytics.
