"""Vendor-neutral ANPR adapter interface."""
from abc import ABC, abstractmethod
from typing import Any
from backend.schemas.anpr_event import ANPREvent

class ANPRAdapter(ABC):
    @abstractmethod
    def parse_event(self, payload: Any) -> ANPREvent:
        raise NotImplementedError
