"""Synthetic ANPR adapter for development and tests."""
from datetime import datetime, timezone
from uuid import uuid4
from backend.schemas.anpr_event import ANPREvent
from .base import ANPRAdapter

class SimulatorAdapter(ANPRAdapter):
    def parse_event(self, payload: dict) -> ANPREvent:
        return ANPREvent(
            event_id=str(uuid4()),
            timestamp=datetime.now(timezone.utc),
            site_id=payload.get("site_id", "SITE-001"),
            camera_id=payload.get("camera_id", "CAM-001"),
            plate_number=payload["plate_number"],
            country=payload.get("country", "UAE"),
            state=payload.get("state"),
            plate_category=payload.get("plate_category"),
            vehicle_type=payload.get("vehicle_type"),
            vehicle_make=payload.get("vehicle_make"),
            vehicle_model=payload.get("vehicle_model"),
            vehicle_color=payload.get("vehicle_color"),
            direction=payload.get("direction"),
            confidence=payload.get("confidence"),
        )
