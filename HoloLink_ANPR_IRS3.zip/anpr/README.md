# ANPR Module

Receives and stores vehicle recognition events. v0.1 uses synthetic events from the simulator.
