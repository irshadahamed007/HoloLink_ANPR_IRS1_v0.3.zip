from fastapi import FastAPI
from pydantic import BaseModel

app=FastAPI(title="HoloLink ANPR API",version="0.2.0")

class ANPREvent(BaseModel):
    plate_number:str
    site_id:str="SITE-001"
    camera_id:str="CAM-001"
    direction:str="ENTRY"
    country:str="UAE"
    state:str|None=None
    vehicle_type:str|None=None
    vehicle_make:str|None=None
    vehicle_model:str|None=None
    vehicle_color:str|None=None
    confidence:float=0.95

@app.get("/")
def root():
    return {"application":"HoloLink","version":"0.2.0","status":"online"}

@app.get("/health")
def health():
    return {"status":"healthy"}

@app.post("/api/anpr/event")
def receive_anpr_event(event:ANPREvent):
    return {"status":"received","event":event.model_dump()}
