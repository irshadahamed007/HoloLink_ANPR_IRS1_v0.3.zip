"""Canonical HoloLink ANPR event contract."""
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

@dataclass
class ANPREvent:
    event_id: str
    timestamp: datetime
    site_id: str
    camera_id: str
    plate_number: str
    country: Optional[str] = None
    state: Optional[str] = None
    plate_category: Optional[str] = None
    vehicle_type: Optional[str] = None
    vehicle_make: Optional[str] = None
    vehicle_model: Optional[str] = None
    vehicle_color: Optional[str] = None
    direction: Optional[str] = None
    confidence: Optional[float] = None
    image_url: Optional[str] = None
    plate_image_url: Optional[str] = None
