from dataclasses import dataclass
from datetime import datetime
from typing import Optional

@dataclass
class Vehicle:
    plate_number:str
    country:str="UAE"
    state:Optional[str]=None
    vehicle_type:Optional[str]=None
    make:Optional[str]=None
    model:Optional[str]=None
    color:Optional[str]=None

@dataclass
class ANPREvent:
    event_id:str
    timestamp:datetime
    site_id:str
    camera_id:str
    plate_number:str
    direction:str
    confidence:float=0.95
