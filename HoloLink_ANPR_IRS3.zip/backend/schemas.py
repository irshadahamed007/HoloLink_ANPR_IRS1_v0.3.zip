from datetime import datetime
from pydantic import BaseModel, ConfigDict, Field


class ANPREventCreate(BaseModel):
    plate: str = Field(min_length=1, max_length=32)
    country: str
    category: str
    vehicle_type: str
    make: str
    model: str
    color: str
    camera_id: str
    site_id: str
    direction: str
    timestamp: datetime | None = None


class ANPREventResponse(ANPREventCreate):
    model_config = ConfigDict(from_attributes=True)
    id: int
    timestamp: datetime


class ParkingSessionCreate(BaseModel):
    plate: str
    entry_time: datetime | None = None


class ParkingSessionResponse(ParkingSessionCreate):
    model_config = ConfigDict(from_attributes=True)
    id: int
    exit_time: datetime | None
    duration_minutes: int | None
    fee: float | None
    payment_status: str
