# Roadmap

- [x] v0.1 API foundation
- [x] v0.1 ANPR simulator
- [x] v0.1 vehicle search
- [x] v0.1 vehicle history
- [x] v0.1 parking session POC
- [ ] v0.4 ANPR MCP server
- [ ] v0.5 AI agent
- [ ] v0.6 voice interaction
- [ ] v0.7 web dashboard
- [ ] v1.0 integrated POC
