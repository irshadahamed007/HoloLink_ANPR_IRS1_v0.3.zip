# HoloLink MCP Tool Contract

Initial tool set:

- `search_vehicle`
- `get_vehicle_history`
- `get_vehicle_last_seen`
- `get_site_status`
- `get_camera_status`
- `get_recent_anpr_events`
- `get_vehicle_statistics`
- `get_alerts`
- `get_parking_status`

Security requirements:

- authenticate MCP clients
- authorize tools by role
- validate all arguments
- audit every tool invocation
- never expose raw database credentials to the AI agent
