# Security Baseline

- Use environment variables for secrets.
- Never commit `.env` files.
- Use strong API authentication.
- Apply role-based access control.
- Audit vehicle-data access.
- Encrypt production traffic with TLS.
- Keep customer ANPR images out of public Git repositories.
- Use synthetic data for GitHub tests and examples.
