# Architecture

## v0.1

```text
ANPR Simulator
      |
      v
FastAPI ANPR API
      |
      v
SQLAlchemy
      |
      v
SQLite
```

## Target architecture

```text
ANPR Camera
    |
ANPR Application
    |
ANPR API
    |
HoloLink Backend
    |
+---+----------------+
|                    |
Database          MCP Server
                     |
                  AI Agent
                     |
              Voice / Chat UI
```
