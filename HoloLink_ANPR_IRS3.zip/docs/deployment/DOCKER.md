# Deployment

Recommended production separation:

1. API service
2. Worker/event processor
3. PostgreSQL
4. Redis or MQTT
5. MCP service
6. Dashboard
7. Monitoring

For a small POC these services can run on one host; production deployments
should separate workloads according to scale and security requirements.
