# Database

v0.1 uses SQLite through SQLAlchemy. PostgreSQL can be introduced for multi-site deployments.
