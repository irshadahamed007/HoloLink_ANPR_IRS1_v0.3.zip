-- HoloLink v0.2 PostgreSQL starter schema
CREATE TABLE IF NOT EXISTS sites (
    site_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'unknown'
);

CREATE TABLE IF NOT EXISTS cameras (
    camera_id TEXT PRIMARY KEY,
    site_id TEXT NOT NULL REFERENCES sites(site_id),
    name TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'unknown'
);

CREATE TABLE IF NOT EXISTS anpr_events (
    event_id TEXT PRIMARY KEY,
    timestamp TIMESTAMPTZ NOT NULL,
    site_id TEXT NOT NULL REFERENCES sites(site_id),
    camera_id TEXT NOT NULL REFERENCES cameras(camera_id),
    plate_number TEXT NOT NULL,
    country TEXT,
    state TEXT,
    plate_category TEXT,
    vehicle_type TEXT,
    vehicle_make TEXT,
    vehicle_model TEXT,
    vehicle_color TEXT,
    direction TEXT,
    confidence DOUBLE PRECISION,
    image_url TEXT,
    plate_image_url TEXT
);

CREATE INDEX IF NOT EXISTS idx_anpr_plate ON anpr_events(plate_number);
CREATE INDEX IF NOT EXISTS idx_anpr_timestamp ON anpr_events(timestamp);
CREATE INDEX IF NOT EXISTS idx_anpr_site ON anpr_events(site_id);
