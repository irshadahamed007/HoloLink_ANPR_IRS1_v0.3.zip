# AI Agent

Planned v0.5 module. The agent will use controlled ANPR MCP tools for natural-language vehicle and parking queries.
