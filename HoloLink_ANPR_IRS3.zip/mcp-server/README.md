# ANPR MCP Server

Planned v0.4 module. Initial tools will include `search_vehicle`, `get_vehicle_history`, `get_vehicle_location`, `get_parking_session`, and `get_site_status`.
