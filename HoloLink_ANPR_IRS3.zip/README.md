# HoloLink

**AI-powered ANPR vehicle intelligence platform with voice interaction, MCP integration, parking analytics, and real-time vehicle search.**

> HoloLink is a vendor-neutral proof-of-concept. It uses synthetic ANPR data and is not connected to any production ANPR system.

## v0.1 Scope

- FastAPI backend
- SQLite database
- Synthetic ANPR event simulator
- Vehicle search
- Vehicle recognition history
- Parking session creation
- Basic parking fee calculation
- Health/status endpoints
- Automated API tests
- Docker support

## Architecture

```text
ANPR Camera / Simulator
          |
          v
     ANPR API
          |
          v
   SQLite / PostgreSQL
          |
    +-----+------+
    |            |
Vehicle Search  Parking
    |
    v
 Future MCP Server
    |
    v
 Future AI / Voice Agent
```

## Requirements

- Python 3.11+
- Git
- Optional: Docker

## Run locally

### 1. Create environment

Windows PowerShell:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
```

Linux/macOS:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 2. Install

```bash
pip install -r requirements.txt
```

### 3. Start API

```bash
uvicorn backend.main:app --reload
```

Open:

- API: http://127.0.0.1:8000
- Swagger: http://127.0.0.1:8000/docs
- ReDoc: http://127.0.0.1:8000/redoc

FastAPI provides interactive OpenAPI documentation at `/docs`. 

### 4. Generate demo ANPR events

In another terminal:

```bash
python simulator/anpr_simulator.py --count 20
```

### 5. Run tests

```bash
pytest
```

## API examples

Create an ANPR event:

```bash
curl -X POST http://127.0.0.1:8000/api/v1/anpr/events \
  -H "Content-Type: application/json" \
  -d "{\"plate\":\"A12345\",\"country\":\"UAE\",\"category\":\"Private\",\"vehicle_type\":\"SUV\",\"make\":\"Toyota\",\"model\":\"Land Cruiser\",\"color\":\"White\",\"camera_id\":\"CAM-001\",\"site_id\":\"SITE-001\",\"direction\":\"ENTRY\"}"
```

Search a vehicle:

```text
GET /api/v1/vehicles/A12345
```

Vehicle history:

```text
GET /api/v1/vehicles/A12345/history
```

Create parking session:

```text
POST /api/v1/parking/sessions
```

## Project structure

```text
HoloLink/
├── backend/
│   ├── __init__.py
│   ├── main.py
│   ├── database.py
│   ├── models.py
│   └── schemas.py
├── simulator/
│   └── anpr_simulator.py
├── mcp-server/
│   └── README.md
├── ai-agent/
│   └── README.md
├── parking/
│   └── README.md
├── anpr/
│   └── README.md
├── dashboard/
│   └── README.md
├── database/
│   └── README.md
├── docs/
│   ├── architecture.md
│   └── roadmap.md
├── tests/
│   └── test_api.py
├── .github/workflows/ci.yml
├── .env.example
├── .gitignore
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
└── README.md
```

## Roadmap

- v0.1: ANPR core
- v0.2: vehicle intelligence
- v0.3: parking analytics
- v0.4: MCP server
- v0.5: AI agent
- v0.6: voice interaction
- v0.7: dashboard
- v1.0: integrated POC

## Security

Never commit production plate data, passwords, API keys, license keys, customer IP addresses, or proprietary source code. Use synthetic data for this repository.

## License

MIT
