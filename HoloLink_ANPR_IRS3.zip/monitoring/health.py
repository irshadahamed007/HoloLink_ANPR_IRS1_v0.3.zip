"""Lightweight health model for HoloLink services."""
from datetime import datetime, timezone

def health():
    return {
        "status": "healthy",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "service": "hololink",
    }
