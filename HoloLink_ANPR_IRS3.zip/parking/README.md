# Parking Module

Contains parking-session and proof-of-concept fee logic. Payment integration is intentionally not connected in v0.1.
